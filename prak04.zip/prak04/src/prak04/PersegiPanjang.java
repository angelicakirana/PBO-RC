/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prak04;

/**
 *
 * @author Mahasiswa
 */
public class PersegiPanjang extends Bentuk{
    double p,l;
    
    public PersegiPanjang(double p, double l){
        this.p=p;
        this.l=l;
        
    }

    public double getP() {
        return p;
    }

    public double getL() {
        return l;
    }


    public double getLuas() {
        return l*p;
    }
    
    
    }

