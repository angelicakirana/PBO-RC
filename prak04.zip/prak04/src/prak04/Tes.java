/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prak04;

/**
 *
 * @author Mahasiswa
 */
public class Tes {
   public static void main(String[] args) {
    Lingkaran o = new Lingkaran(7);
    System.out.println(o.getLuas());
}
}