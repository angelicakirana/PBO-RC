/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prak04;

/**
 *
 * @author Mahasiswa
 */
public class Segitiga {
double a,t;

public Segitiga(double a, double t){
    this.a=a;
    this.t=t;
    
}

    public double getA() {
        return a;
    }

    public double getT() {
        return t;
    }
    public double getLuas(){
        return (a*t)/2;
    }

 
}
