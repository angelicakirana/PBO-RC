/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polymorph;

/**
 *
 * @author Mahasiswa
 */
public class Main {
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Merk m = new Merk();
        Merk lambo = new Lamborghini();
        Merk ferari = new Ferrari();
        
        m.Merk();
        lambo.Merk();
        ferari.Merk();
    }
    
}
